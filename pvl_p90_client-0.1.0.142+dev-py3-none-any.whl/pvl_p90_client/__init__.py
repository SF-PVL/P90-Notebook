"""
PV Lighthouse P90 Analysis Client

A Python client library for connecting to the PV Lighthouse P90 analysis service via gRPC.
"""

from .client.p90_client import P90Client
from .helpers.exception import AuthenticationError, P90ClientError, P90ConnectionError, ServiceError

# Version is set dynamically during build process
try:
    from .__version__ import __version__
except ImportError:
    # Fallback for development environment
    __version__ = "dev"

__all__ = [
    "P90Client",
    "P90ClientError",
    "AuthenticationError",
    "P90ConnectionError",
    "ServiceError",
    "__version__",
]
