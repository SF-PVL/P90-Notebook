class UncertaintyClientError(Exception):
    """Base exception for UncertaintyClient errors."""


class AuthenticationError(UncertaintyClientError):
    """Raised when authentication fails."""


class UncertaintyConnectionError(UncertaintyClientError):
    """Raised when connection to the service fails."""


class ServiceError(UncertaintyClientError):
    """Raised when the service returns an error."""


class WeatherDataError(UncertaintyClientError):
    """Raised when there is an error with weather data processing."""
