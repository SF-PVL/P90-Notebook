import math

from pvl_uncertainty_client.grpcclient import uncertaintyMessages_pb2, weatherData_pb2

from .exception import WeatherDataError


def _extract_float_from_nullable(nullable_float: weatherData_pb2.NullableFloat) -> float | None:
    """Extract float value from NullableFloat, returning None if null."""
    if hasattr(nullable_float, "null") and nullable_float.HasField("null"):
        return None
    return nullable_float.data if hasattr(nullable_float, "data") else None


def build_module_info(length: float, width: float) -> uncertaintyMessages_pb2.ModuleInfo:
    """Builds and returns a ModuleInfo message with default values."""
    module_info = uncertaintyMessages_pb2.ModuleInfo()
    module_info.LengthInM = length
    module_info.WidthInM = width
    return module_info


def build_system_info(
    num_strings: int,
    modules_per_string: int,
    inverter_efficiency_rate: float,
    row_pitch_in_m: float,
    module_to_module_mismatch_rate: float,
    wiring_loss_rate: float,
    max_power_tracking_rate: float,
    azimuth_in_rad: float,
) -> uncertaintyMessages_pb2.SystemInfo:
    """Builds and returns a SystemInfo message with default values."""
    system_info = uncertaintyMessages_pb2.SystemInfo()
    system_info.NumberOfStrings = num_strings
    system_info.InverterEfficiencyRate = inverter_efficiency_rate
    system_info.ModulesPerString = modules_per_string
    system_info.RowPitchInM = row_pitch_in_m
    system_info.ModuleToModuleMismatchRate = module_to_module_mismatch_rate
    system_info.WiringLossRate = wiring_loss_rate
    system_info.MaxPowerTrackingRate = max_power_tracking_rate
    system_info.ModuleAzimuthInRadians = azimuth_in_rad
    return system_info


def build_result_options(p_min: float, p_delta: float, p_values: list[int]) -> uncertaintyMessages_pb2.ResultOptions:
    """Builds and returns a ResultOptions message with default values."""
    result_options = uncertaintyMessages_pb2.ResultOptions()
    result_options.PDelta = p_delta
    result_options.PValues.extend(p_values)
    result_options.PMin = p_min
    return result_options


def build_simulation_options(number_of_years: int, number_of_simulations: int) -> uncertaintyMessages_pb2.UncertaintySimulationOptions:
    """Builds and returns a SimulationOptions message with default values."""
    simulation_options = uncertaintyMessages_pb2.UncertaintySimulationOptions()
    simulation_options.NumberOfYears = number_of_years
    simulation_options.NumberOfSimulations = number_of_simulations
    return simulation_options


def build_modifier(
    target: uncertaintyMessages_pb2.ModifierTarget,
    simulation_error: uncertaintyMessages_pb2.ErrorFunction | None = None,
    yearly_error: uncertaintyMessages_pb2.ErrorFunction | None = None,
    time_step_error: uncertaintyMessages_pb2.ErrorFunction | None = None,
) -> uncertaintyMessages_pb2.Modifier:  # type: ignore
    """Builds and returns a Modifier message."""
    modifier = uncertaintyMessages_pb2.Modifier()
    modifier.Target = target

    if simulation_error is not None:
        modifier.SimulationError.CopyFrom(simulation_error)
    if yearly_error is not None:
        modifier.YearlyError.CopyFrom(yearly_error)
    if time_step_error is not None:
        modifier.TimeStepError.CopyFrom(time_step_error)
    return modifier


def build_gaussian_error_function(
    x0: float,
    sigma: float,
    fmax: float | None = None,
    num_points_in_probability_function: int | None = None,
    lower_limit: float | None = None,
    upper_limit: float | None = None,
) -> uncertaintyMessages_pb2.ErrorFunction:
    """Builds and returns an ErrorFunction message."""
    error_function = uncertaintyMessages_pb2.ErrorFunction()
    error_function.Type = uncertaintyMessages_pb2.ErrorFunctionType.Gaussian
    error_function.GaussianFunction.x0 = x0
    error_function.GaussianFunction.sigma = sigma

    if fmax is not None:
        error_function.GaussianFunction.fmax = fmax
    if num_points_in_probability_function is not None:
        error_function.GaussianFunction.numPointsInProbabilityFunction = num_points_in_probability_function
    if lower_limit is not None:
        error_function.GaussianFunction.xLowerLimit = lower_limit
    if upper_limit is not None:
        error_function.GaussianFunction.xUpperLimit = upper_limit

    return error_function


def build_skewed_gaussian_error_function(
    alpha: float,
    zeta: float,
    omega: float,
    fmax: float | None = None,
    num_points_in_probability_function: int | None = None,
) -> uncertaintyMessages_pb2.ErrorFunction:
    """Builds and returns an ErrorFunction message."""
    error_function = uncertaintyMessages_pb2.ErrorFunction()
    error_function.Type = uncertaintyMessages_pb2.ErrorFunctionType.SkewedGaussian
    error_function.SkewedGaussianFunction.alpha = alpha
    error_function.SkewedGaussianFunction.zeta = zeta
    error_function.SkewedGaussianFunction.omega = omega

    if fmax is not None:
        error_function.SkewedGaussianFunction.fmax = fmax
    if num_points_in_probability_function is not None:
        error_function.SkewedGaussianFunction.numPointsInProbabilityFunction = num_points_in_probability_function

    return error_function


def build_weibull_error_function(x0: float, lambda_term: float, k: float, has_positive_polarity: bool | None = None) -> uncertaintyMessages_pb2.ErrorFunction:
    """Builds and returns an ErrorFunction message."""
    error_function = uncertaintyMessages_pb2.ErrorFunction()
    error_function.Type = uncertaintyMessages_pb2.ErrorFunctionType.Weibull
    error_function.WeibullFunction.x0 = x0
    error_function.WeibullFunction.k = k
    # Note: 'lambda' is a Python keyword, so we use getattr/setattr
    setattr(error_function.WeibullFunction, "lambda", lambda_term)

    if has_positive_polarity is not None:
        error_function.WeibullFunction.hasPositivePolarity = has_positive_polarity

    return error_function


def build_arbitrary_error_function(x: list[float], y: list[float]) -> uncertaintyMessages_pb2.ErrorFunction:
    error_function = uncertaintyMessages_pb2.ErrorFunction()
    error_function.Type = uncertaintyMessages_pb2.ErrorFunctionType.Arbitrary
    # Create the nested message properly
    arbitrary_func = error_function.ArbitraryFunction
    arbitrary_func.x[:] = x  # Use slice assignment for repeated fields
    arbitrary_func.y[:] = y  # Use slice assignment for repeated fields
    return error_function


def load_weather_data_from_pvw_file(
    file_path: str,
) -> list[uncertaintyMessages_pb2.WeatherData] | None:
    """Load weather data from a .pvw file and convert it to WeatherData messages.

    Returns None if the file cannot be loaded or parsed.
    """
    try:
        weather_data = []
        with open(file_path, "rb") as f:
            data = f.read()
            weather_setting = weatherData_pb2.WeatherSetting()
            weather_setting.ParseFromString(data)
            for row in weather_setting.weatherRows:
                # Convert temperature from Celsius to Kelvin if available
                temp_celsius = _extract_float_from_nullable(row.DryBulbTemperature_DegreesCeliusAt2Metres)
                temp_kelvin = celsius_to_kelvin(temp_celsius) if temp_celsius is not None else None

                point = uncertaintyMessages_pb2.WeatherData(
                    EndOfPeriodUTC=row.ObservationTime_UTC,
                    SolarPos=uncertaintyMessages_pb2.YieldTimeSeriesSolarPosition(
                        AzimuthDegrees=_extract_float_from_nullable(row.SolarAzimuth), ZenithDegrees=_extract_float_from_nullable(row.SolarZenith)
                    ),
                    Weather=uncertaintyMessages_pb2.YieldTimeSeriesWeather(
                        AmbientTemp=temp_kelvin,
                        DHI=_extract_float_from_nullable(row.DiffuseHorizontalIrradiance_WattsPerMetreSquared),
                        GHI=_extract_float_from_nullable(row.GlobalHorizontalIrradiance_WattsPerMetreSquared),
                        DNI=_extract_float_from_nullable(row.DirectNormalIrradiance_WattsPerMetreSquared),
                        WS=_extract_float_from_nullable(row.WindVelocity_MetresPerSecondAt10Metres),
                    ),
                )

                weather_data.append(point)
        return weather_data
    except (FileNotFoundError, OSError) as e:
        print(f"Error loading weather data from {file_path}: {e}")
        raise WeatherDataError("Failed to load weather data") from e
    except Exception as e:
        print(f"Error parsing weather data from {file_path}: {e}")
        raise WeatherDataError("Failed to load weather data") from e


def celsius_to_kelvin(celsius: float | None) -> float | None:
    """Convert Celsius to Kelvin, handling None values."""
    return celsius + 273.15 if celsius is not None else None


def degrees_to_radians(degrees: float) -> float:
    return degrees * (math.pi / 180.0)
