"""
PV Lighthouse Uncertainty Analysis Client

A Python client library for connecting to the PV Lighthouse uncertainty analysis service via gRPC.
"""

from .client.uncertainty_client import UncertaintyClient
from .helpers.exception import AuthenticationError, ServiceError, UncertaintyClientError, UncertaintyConnectionError

# Version is set dynamically during build process
try:
    from .__version__ import __version__
except ImportError:
    # Fallback for development environment
    __version__ = "dev"

__all__ = [
    "UncertaintyClient",
    "UncertaintyClientError",
    "AuthenticationError",
    "UncertaintyConnectionError",
    "ServiceError",
    "__version__",
]
