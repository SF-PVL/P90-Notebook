"""Version information for pvl-uncertainty-client package."""

__version__: str = "0.1.0.62"
