import logging
import sys

import grpc

from ..grpcclient import uncertainty_grpc_client, uncertaintyMessages_pb2
from ..helpers.exception import AuthenticationError, ServiceError, UncertaintyConnectionError


class UncertaintyClient:
    """A gRPC client for the PV Lighthouse uncertainty analysis service."""

    def __init__(self, api_base_uri: str = "middleware.pvlighthouse.com.au", version: str = "7.19.0"):
        """Initialize the UncertaintyClient."""
        try:
            self.channel = grpc.secure_channel(api_base_uri, grpc.ssl_channel_credentials())
            self.client = uncertainty_grpc_client.UncertaintyStub(self.channel)
            self.metadata = (("version", version),)
            logging.info("Connected to uncertainty service at %s", api_base_uri)
        except Exception as e:
            raise UncertaintyConnectionError(f"Failed to connect to uncertainty service at {api_base_uri}: {e}") from e

    def _handle_grpc_error(self, error: grpc.RpcError, timeout: float | None) -> None:
        """Handle specific gRPC errors and raise appropriate exceptions."""
        error_handlers = {
            grpc.StatusCode.UNAUTHENTICATED: lambda: AuthenticationError("Authentication failed. Please check your credentials."),
            grpc.StatusCode.PERMISSION_DENIED: lambda: AuthenticationError("Permission denied. Please check your account permissions."),
            grpc.StatusCode.UNIMPLEMENTED: lambda: ServiceError("Service endpoint not implemented or not found."),
            grpc.StatusCode.UNAVAILABLE: lambda: UncertaintyConnectionError("Service is currently unavailable. Please try again later."),
            grpc.StatusCode.DEADLINE_EXCEEDED: lambda: TimeoutError(f"Request timed out after {timeout} seconds."),
            grpc.StatusCode.INVALID_ARGUMENT: lambda: ValueError(f"Invalid request parameters: {error.details()}"),
            grpc.StatusCode.CANCELLED: lambda: UncertaintyConnectionError("Request was cancelled. This may happen if the stream is closed unexpectedly."),
            grpc.StatusCode.ABORTED: lambda: UncertaintyConnectionError("Request was aborted by the server. The stream may have been interrupted."),
        }

        if handler := error_handlers.get(error.code()):
            raise handler() from error
        raise ServiceError(f"Service error ({error.code().name}): {error.details()}") from error

    def send_uncertainty_request(
        self,
        request: uncertaintyMessages_pb2.UncertaintyRequest,
        call_credentials: grpc.CallCredentials,
        timeout: float | None = 30.0,
    ) -> uncertaintyMessages_pb2.UncertaintySummary | None:
        """Send an uncertainty analysis request and return the summary results."""
        if not request.WeatherDataPoints:
            raise ValueError("Request must contain weather data points")

        summary = None

        try:
            logging.info("Starting uncertainty analysis request")
            response_stream = self.client.UncertaintyAnalysis(request, metadata=self.metadata, credentials=call_credentials, timeout=timeout)

            for response in response_stream:
                received: uncertaintyMessages_pb2.UncertaintyResponse = response

                # Overwrite the same line with progress
                sys.stdout.write(f"\rProgress: {received.pctComplete * 100:.2f}%")
                sys.stdout.flush()

                # Check for summary in response
                if received.HasField("Summary"):
                    summary = received.Summary
                    print("\n")
                    logging.info("Received uncertainty analysis summary")
                    print(f"Analysis complete! Summary contains {len(summary.YearlyPValue)} yearly P-values")

        except grpc.RpcError as e:
            print("\n")
            logging.error("gRPC error during uncertainty analysis: %s", e)
            self._handle_grpc_error(e, timeout)
        except (ValueError, TypeError, AttributeError) as e:
            print("\n")
            logging.error("Unexpected error during uncertainty analysis: %s", e)
            raise UncertaintyConnectionError(f"Unexpected error during uncertainty analysis: {e}") from e

        if not summary or not summary.YearlyPValue:
            print("\n")
            logging.warning("No results received from uncertainty analysis")

        return summary

    def close(self) -> None:
        """Close the gRPC channel and clean up resources."""
        try:
            self.channel.close()
            logging.info("Uncertainty client connection closed")
        except Exception as e:
            logging.warning("Error closing uncertainty client: %s", e)
            raise UncertaintyConnectionError(f"Unexpected error during uncertainty analysis: {e}") from e

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
