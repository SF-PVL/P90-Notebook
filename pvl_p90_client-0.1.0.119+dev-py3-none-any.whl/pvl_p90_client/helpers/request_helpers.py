import csv
import math
from datetime import datetime, timezone

from pvl_p90_client.grpcclient import weatherData_pb2
from pvl_p90_client.grpcclient.uncertaintyMessages_pb2 import (
    Distribution,
    DistributionFunction,
    DistributionInput,
    DistributionType,
    ModuleInfo,
    ResultOptions,
    SystemInfo,
    TimeStepData,
    UncertaintySimulationOptions,
    YieldTimeSeriesSolarPosition,
    YieldTimeSeriesWeather,
)

from .exception import TimeStepDataError


def _extract_float_from_nullable(nullable_float: weatherData_pb2.NullableFloat) -> float | None:
    """Extract float value from NullableFloat, returning None if null."""
    if hasattr(nullable_float, "null") and nullable_float.HasField("null"):
        return None
    return nullable_float.data if hasattr(nullable_float, "data") else None


def build_module_info(length: float, width: float) -> ModuleInfo:
    """Builds and returns a ModuleInfo message with default values."""
    module_info = ModuleInfo()
    module_info.LengthInM = length
    module_info.WidthInM = width
    return module_info


def build_system_info(
    num_strings: int,
    modules_per_string: int,
    inverter_efficiency_rate: float,
    row_pitch_in_m: float,
    module_to_module_mismatch_rate: float,
    wiring_loss_rate: float,
    max_power_tracking_rate: float,
    azimuth_in_rad: float,
) -> SystemInfo:
    """Builds and returns a SystemInfo message with default values."""
    system_info = SystemInfo()
    system_info.NumberOfStrings = num_strings
    system_info.InverterEfficiencyRate = inverter_efficiency_rate
    system_info.ModulesPerString = modules_per_string
    system_info.RowPitchInM = row_pitch_in_m
    system_info.ModuleToModuleMismatchRate = module_to_module_mismatch_rate
    system_info.WiringLossRate = wiring_loss_rate
    system_info.MaxPowerTrackingRate = max_power_tracking_rate
    system_info.ModuleAzimuthInRadians = azimuth_in_rad
    return system_info


def build_result_options(p_min: float, p_delta: float, p_values: list[int]) -> ResultOptions:
    """Builds and returns a ResultOptions message with default values."""
    result_options = ResultOptions()
    result_options.PDelta = p_delta
    result_options.PValues.extend(p_values)
    result_options.PMin = p_min
    return result_options


def build_simulation_options(number_of_years: int, number_of_simulations: int) -> UncertaintySimulationOptions:
    """Builds and returns a SimulationOptions message with default values."""
    simulation_options = UncertaintySimulationOptions()
    simulation_options.NumberOfYears = number_of_years
    simulation_options.NumberOfSimulations = number_of_simulations
    return simulation_options


def build_distribution(
    input: DistributionInput,
    sim_to_sim_distribution: DistributionFunction | None = None,
    yr_to_yr_distribution: DistributionFunction | None = None,
    step_to_step_distribution: DistributionFunction | None = None,
) -> Distribution:  # type: ignore
    """Builds and returns a Modifier message."""
    distribution = Distribution()
    distribution.Input = input

    if sim_to_sim_distribution is not None:
        distribution.SimToSimDistribution.CopyFrom(sim_to_sim_distribution)
    if yr_to_yr_distribution is not None:
        distribution.YrToYrDistribution.CopyFrom(yr_to_yr_distribution)
    if step_to_step_distribution is not None:
        distribution.StepToStepDistribution.CopyFrom(step_to_step_distribution)
    return distribution


def build_gaussian_distribution(
    x0: float,
    sigma: float,
    fmax: float | None = None,
    num_points_in_probability_function: int | None = None,
    lower_limit: float | None = None,
    upper_limit: float | None = None,
) -> DistributionFunction:
    """Builds and returns an ErrorFunction message."""
    distribution = DistributionFunction()
    distribution.Type = DistributionType.Gaussian
    distribution.Gaussian.x0 = x0
    distribution.Gaussian.sigma = sigma

    if fmax is not None:
        distribution.Gaussian.fmax = fmax
    if num_points_in_probability_function is not None:
        distribution.Gaussian.numPointsInProbabilityFunction = num_points_in_probability_function
    if lower_limit is not None:
        distribution.Gaussian.xLowerLimit = lower_limit
    if upper_limit is not None:
        distribution.Gaussian.xUpperLimit = upper_limit

    return distribution


def build_skewed_gaussian_distribution(
    alpha: float,
    zeta: float,
    omega: float,
    fmax: float | None = None,
    num_points_in_probability_function: int | None = None,
) -> DistributionFunction:
    """Builds and returns an ErrorFunction message."""
    distribution = DistributionFunction()
    distribution.Type = DistributionType.SkewedGaussian
    distribution.SkewedGaussian.alpha = alpha
    distribution.SkewedGaussian.zeta = zeta
    distribution.SkewedGaussian.omega = omega

    if fmax is not None:
        distribution.SkewedGaussian.fmax = fmax
    if num_points_in_probability_function is not None:
        distribution.SkewedGaussian.numPointsInProbabilityFunction = num_points_in_probability_function

    return distribution


def build_weibull_distribution(x0: float, lambda_term: float, k: float, has_positive_polarity: bool | None = None) -> DistributionFunction:
    """Builds and returns an ErrorFunction message."""
    distribution = DistributionFunction()
    distribution.Type = DistributionType.Weibull
    distribution.Weibull.x0 = x0
    distribution.Weibull.k = k
    # Note: 'lambda' is a Python keyword, so we use getattr/setattr
    setattr(distribution.Weibull, "lambda", lambda_term)

    if has_positive_polarity is not None:
        distribution.Weibull.hasPositivePolarity = has_positive_polarity

    return distribution


def build_arbitrary_distribution(x: list[float], y: list[float]) -> DistributionFunction:
    distribution = DistributionFunction()
    distribution.Type = DistributionType.Arbitrary
    # Create the nested message properly
    arbitrary_func = distribution.Arbitrary
    arbitrary_func.x[:] = x  # Use slice assignment for repeated fields
    arbitrary_func.y[:] = y  # Use slice assignment for repeated fields
    return distribution


def load_weather_data_from_pvw_file(file_path: str) -> list[TimeStepData] | None:
    """Load weather data from a .pvw file and convert it to WeatherData messages.

    Returns None if the file cannot be loaded or parsed.
    """
    try:
        weather_data = []
        with open(file_path, "rb") as f:
            data = f.read()
            weather_setting = weatherData_pb2.WeatherSetting()
            weather_setting.ParseFromString(data)
            for row in weather_setting.weatherRows:
                # Convert temperature from Celsius to Kelvin if available
                temp_celsius = _extract_float_from_nullable(row.DryBulbTemperature_DegreesCeliusAt2Metres)
                temp_kelvin = celsius_to_kelvin(temp_celsius) if temp_celsius is not None else None

                point = TimeStepData(
                    EndOfPeriodUTC=row.ObservationTime_UTC,
                    SolarPos=YieldTimeSeriesSolarPosition(
                        AzimuthDegrees=_extract_float_from_nullable(row.SolarAzimuth), ZenithDegrees=_extract_float_from_nullable(row.SolarZenith)
                    ),
                    Weather=YieldTimeSeriesWeather(
                        AmbientTemp=temp_kelvin,
                        DHI=_extract_float_from_nullable(row.DiffuseHorizontalIrradiance_WattsPerMetreSquared),
                        GHI=_extract_float_from_nullable(row.GlobalHorizontalIrradiance_WattsPerMetreSquared),
                        DNI=_extract_float_from_nullable(row.DirectNormalIrradiance_WattsPerMetreSquared),
                        WS=_extract_float_from_nullable(row.WindVelocity_MetresPerSecondAt10Metres),
                    ),
                )

                weather_data.append(point)
        return weather_data
    except (FileNotFoundError, OSError) as e:
        print(f"Error loading weather data from {file_path}: {e}")
        raise TimeStepDataError("Failed to load weather data") from e
    except Exception as e:
        print(f"Error parsing weather data from {file_path}: {e}")
        raise TimeStepDataError("Failed to load weather data") from e


def load_time_step_data_from_csv(file_path: str) -> list[TimeStepData]:
    """Load weather data from a CSV file and convert it to TimeStepData messages.

    The CSV file must start with a version header: # P90_CSV_VERSION=1.0

    The CSV file is expected to have the following columns:
    - EndOfPeriodUTC (dd/mm/yyyy HH:mm)
    - SolarAzimuth (degrees)
    - SolarZenith (degrees)
    - AmbientTemp (celsius)
    - DHI (W/m2)
    - GHI (W/m2)
    - DNI (W/m2)
    - WS (m/s)
    - Tilt (degrees)

    Returns a list of TimeStepData messages.

    Raises:
        TimeStepDataError: If the file format is invalid, version is missing/unsupported, or required columns are missing.
    """
    # Define expected columns
    expected_columns = {
        "EndOfPeriodUTC (dd/mm/yyyy HH:mm)",
        "SolarAzimuth (degrees)",
        "SolarZenith (degrees)",
        "AmbientTemp (celsius)",
        "DHI (W/m2)",
        "GHI (W/m2)",
        "DNI (W/m2)",
        "WS (m/s)",
        "Tilt (degrees)",
    }

    weather_data = []
    try:
        with open(file_path, newline="") as csvfile:
            # Check for required version header
            first_line = csvfile.readline().strip()

            if not first_line.startswith("# P90_CSV_VERSION="):
                raise TimeStepDataError(f"CSV file {file_path} is missing required version header. Expected: # P90_CSV_VERSION=1.0")

            # Extract and validate version
            version = first_line.split("=")[1].strip()
            if version != "1.0":
                raise TimeStepDataError(f"Unsupported CSV format version: {version}. Only version 1.0 is currently supported.")

            # Save position after version header
            header_position = csvfile.tell()

            # First, try to detect if it's a valid CSV with comma separator
            sample = csvfile.read(1024)

            # Use csv.Sniffer to detect format
            sniffer = csv.Sniffer()
            try:
                dialect = sniffer.sniff(sample, delimiters=",")
                if dialect.delimiter != ",":
                    raise TimeStepDataError(f"File {file_path} must use comma as separator, found '{dialect.delimiter}'")
            except csv.Error as e:
                raise TimeStepDataError(f"File {file_path} does not appear to be a valid CSV format") from e

            # Check if file has a header
            if not sniffer.has_header(sample):
                raise TimeStepDataError(f"File {file_path} must have a header row")

            # Seek back to position after version header to read the CSV
            csvfile.seek(header_position)

            # Read the CSV with detected dialect
            reader = csv.DictReader(csvfile, dialect=dialect)

            # Validate that all expected columns are present
            if reader.fieldnames is None:
                raise TimeStepDataError("Unable to read CSV header")

            actual_columns = set(reader.fieldnames)
            missing_columns = expected_columns - actual_columns

            if missing_columns:
                missing_list = sorted(missing_columns)
                raise TimeStepDataError(f"Missing required columns: {', '.join(missing_list)}")

            # Process the data rows
            for row in reader:
                # Parse the datetime string (expected format: dd/mm/yyyy HH:mm)
                try:
                    end_time = datetime.strptime(row["EndOfPeriodUTC (dd/mm/yyyy HH:mm)"], "%d/%m/%Y %H:%M")
                except ValueError as e:
                    date_value = row["EndOfPeriodUTC (dd/mm/yyyy HH:mm)"]
                    raise TimeStepDataError(f"Invalid date format in EndOfPeriodUTC: {date_value}. Expected format: dd/mm/yyyy HH:mm") from e

                temp_celsius = float(row["AmbientTemp (celsius)"]) if row["AmbientTemp (celsius)"] else None
                temp_kelvin = celsius_to_kelvin(temp_celsius) if temp_celsius is not None else None

                # Convert tilt from degrees to radians
                tilt_degrees = float(row["Tilt (degrees)"]) if row["Tilt (degrees)"] else None
                tilt_radians = math.radians(tilt_degrees) if tilt_degrees is not None else None

                point = TimeStepData(
                    EndOfPeriodUTC=end_time,
                    SolarPos=YieldTimeSeriesSolarPosition(
                        AzimuthDegrees=float(row["SolarAzimuth (degrees)"]) if row["SolarAzimuth (degrees)"] else None,
                        ZenithDegrees=float(row["SolarZenith (degrees)"]) if row["SolarZenith (degrees)"] else None,
                    ),
                    Weather=YieldTimeSeriesWeather(
                        AmbientTemp=temp_kelvin,
                        DHI=float(row["DHI (W/m2)"]) if row["DHI (W/m2)"] else None,
                        GHI=float(row["GHI (W/m2)"]) if row["GHI (W/m2)"] else None,
                        DNI=float(row["DNI (W/m2)"]) if row["DNI (W/m2)"] else None,
                        WS=float(row["WS (m/s)"]) if row["WS (m/s)"] else None,
                    ),
                    TiltAngleInRad=tilt_radians,
                )
                weather_data.append(point)
        return weather_data
    except (FileNotFoundError, OSError) as e:
        print(f"Error loading weather data from {file_path}: {e}")
        raise TimeStepDataError("Failed to load weather data") from e
    except TimeStepDataError:
        # Re-raise WeatherDataError as-is
        raise
    except Exception as e:
        print(f"Error parsing weather data from {file_path}: {e}")
        raise TimeStepDataError("Failed to load weather data") from e


def write_timestep_data_to_csv(file_path: str, time_step_data: list[TimeStepData]) -> None:
    """Save time step data to a CSV file with P90 CSV format versioning."""
    with open(file_path, mode="w", newline="") as csvfile:
        # Write version header first
        csvfile.write("# P90_CSV_VERSION=1.0\n")

        fieldnames = [
            "EndOfPeriodUTC (dd/mm/yyyy HH:mm)",
            "SolarAzimuth (degrees)",
            "SolarZenith (degrees)",
            "AmbientTemp (celsius)",
            "DHI (W/m2)",
            "GHI (W/m2)",
            "DNI (W/m2)",
            "WS (m/s)",
            "Tilt (degrees)",
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for point in time_step_data:
            # Convert protobuf Timestamp to Python datetime if it's a Timestamp object
            end_time = point.EndOfPeriodUTC.ToDatetime(tzinfo=timezone.utc)  # noqa

            writer.writerow(
                {
                    "EndOfPeriodUTC (dd/mm/yyyy HH:mm)": end_time.strftime("%d/%m/%Y %H:%M") if isinstance(end_time, datetime) else str(end_time),
                    "SolarAzimuth (degrees)": point.SolarPos.AzimuthDegrees,
                    "SolarZenith (degrees)": point.SolarPos.ZenithDegrees,
                    "AmbientTemp (celsius)": kelvin_to_celsius(point.Weather.AmbientTemp),
                    "DHI (W/m2)": point.Weather.DHI,
                    "GHI (W/m2)": point.Weather.GHI,
                    "DNI (W/m2)": point.Weather.DNI,
                    "WS (m/s)": point.Weather.WS,
                    "Tilt (degrees)": math.degrees(point.TiltAngleInRad) if point.TiltAngleInRad is not None else None,
                }
            )


def celsius_to_kelvin(celsius: float | None) -> float | None:
    """Convert Celsius to Kelvin, handling None values."""
    return celsius + 273.15 if celsius is not None else None


def kelvin_to_celsius(kelvin: float | None) -> float | None:
    """Convert Kelvin to Celsius, handling None values."""
    return kelvin - 273.15 if kelvin is not None else None
